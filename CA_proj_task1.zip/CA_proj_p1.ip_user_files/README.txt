Proofs for amortized analysis, linked list.
Proofs for hashing search algorithms

Then revise codes for early chaps.